/**
 * Facebook Messenger Bot - Main Bot File
 * Handles Facebook login, message listening, and event routing
 */

const { login } = require('neokex-fca');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');

const logger = global.logger;

logger.system('Loading main bot module...');

const appstatePath = path.join(__dirname, 'appstate.json');
let appstate = [];

try {
  if (fs.existsSync(appstatePath)) {
    const appstateContent = fs.readFileSync(appstatePath, 'utf8');
    if (appstateContent && appstateContent.trim()) {
      appstate = JSON.parse(appstateContent);
      logger.system('Loaded appstate.json successfully');
    } else {
      logger.warn('appstate.json is empty, waiting for login credentials...');
    }
  } else {
    logger.warn('appstate.json not found, please provide login credentials');
  }
} catch (error) {
  logger.error('Failed to load appstate.json:', error.message);
}

if (!appstate || appstate.length === 0) {
  logger.warn('No valid appstate found. Please provide appstate.json with valid Facebook session.');
  logger.warn('Bot will continue to run but won\'t process messages until appstate is provided.');
  return;
}

  const fcaOptions = global.config.fcaOptions || {
    forceLogin: false,
    updatePresence: true,
    listenEvents: true,
    logLevel: 'info',
    selfListen: true,
    autoMarkRead: true,
    autoMarkDelivery: true,
    online: true,
    emitReady: true,
    autoReconnect: true,
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
  };

logger.system('Attempting Facebook login...');

login({ appState: appstate }, fcaOptions, (err, api) => {
  if (err) {
    logger.error('Facebook login failed:', err.message || err);
    if (err.error) {
      logger.error('Error details:', JSON.stringify(err.error));
    }
    return;
  }

  logger.system('Facebook login successful!');

  global.api = api;
  global.client.api = api;
  
  const botID = api.getCurrentUserID();
  global.client.botID = botID;
  logger.system(`Bot ID: ${botID}`);

  global.loader.loadCommands();
  global.loader.loadEvents();

  global.handleDatabase.initializeDatabase(api);

  api.setOptions({
    listenEvents: true,
    selfListen: true,
    autoMarkRead: true,
    autoMarkDelivery: true,
    online: true,
    forceLogin: false,
    listenTyping: true,
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
  });

  api.listenMqtt((err, message) => {
    if (err) {
      logger.error('Listen error:', err.message || err);
      return;
    }

    if (!message) return;

    // Only log actual messages (not presence, typing, etc.)
    if (message.type === 'message' && message.senderID) {
      logger.system(`[MSG_RCV] ${message.senderID}: ${message.body || '[Media]'}`);
    }

    handleMessage(api, message).catch(error => {
      logger.error('Error handling message:', error.message);
    });
  });

  logger.system('Bot is now listening for messages!');

  if (global.config.sessionManagement && global.config.sessionManagement.enabled) {
    try {
      const SessionManager = require('./utils/sessionManager');
      const sessionManager = new SessionManager(api, api.getAppState(), fcaOptions, global.config);
      logger.system('Session manager started');
    } catch (error) {
      logger.warn('Session manager not available:', error.message);
    }
  }

  setInterval(() => {
    try {
      const currentAppstate = api.getAppState();
      if (currentAppstate && currentAppstate.length > 0) {
        fs.writeFileSync(appstatePath, JSON.stringify(currentAppstate, null, 2));
        logger.debug('Auto-saved appstate');
      }
    } catch (error) {
      logger.error('Failed to auto-save appstate:', error.message);
    }
  }, 5 * 60 * 1000);
});

async function handleMessage(api, message) {
  const { type, threadID, senderID, body } = message;

  if (senderID === global.client.botID && !global.config.fcaOptions.selfListen) {
    return;
  }

  try {
    const { syncFromMessage } = require('./handles/dynamicDatabaseSync');
    await syncFromMessage(api, message);
    } catch (error) {
    logger.debug('Dynamic sync error:', error.message);
  }

  switch (type) {
    case 'message':
    case 'message_reply':
      await handleMessageType(api, message);
      break;

    case 'message_reaction':
      await handleReactionType(api, message);
      break;

    case 'event':
      await handleEventType(api, message);
      break;

    case 'typ':
    case 'read':
    case 'read_receipt':
    case 'presence':
      break;

    default:
      logger.debug(`Unhandled message type: ${type}`);
  }
}

async function handleMessageType(api, message) {
  const { body, messageReply, senderID, threadID } = message;


  if (messageReply && messageReply.messageID) {
    try {
      await global.handleReply({ api, message });
    } catch (error) {
      logger.error('Reply handler error:', error.message);
    }
  }

  if (body && typeof body === 'string') {
    const prefix = global.config.prefix || '/';
    const noPrefixBody = body.toLowerCase().trim();
    const hasPrefix = body.startsWith(prefix);

    const commandToCheck = hasPrefix ? body.slice(prefix.length).trim().split(' ')[0].toLowerCase() : noPrefixBody.split(' ')[0].toLowerCase();
    const command = global.client.commands.get(commandToCheck);

    if (command) {
      const needsPrefix = command.config.hasPrefix !== false;
      
      if (needsPrefix && !hasPrefix) {
        return;
      }

      try {
        await global.handleCommand({ api, message, command });
      } catch (error) {
        logger.error('Command handler error:', error.message);
        logger.error(error.stack);
      }
    } else {
      // Auto-reply for "Bot" or mentions if no command found
      if (noPrefixBody.includes('bot')) {
        const aiCommand = global.client.commands.get('ai') || global.client.commands.get('gpt');
        if (aiCommand) {
          try {
            await global.handleCommand({ api, message, command: aiCommand });
          } catch (error) {
            logger.error('Auto-AI error:', error.message);
          }
        }
      }
    }
  }
}

async function handleReactionType(api, message) {
  try {
    await global.handleReaction({ api, message });
  } catch (error) {
    logger.error('Reaction handler error:', error.message);
  }
}

async function handleEventType(api, message) {
  if (!global.config.eventEnabled) {
    return;
  }

  try {
    await global.handleEvent({ api, message });
  } catch (error) {
    logger.error('Event handler error:', error.message);
  }
}

logger.system('Main bot module loaded successfully');
