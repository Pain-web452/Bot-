const axios = require('axios');
const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "bot",
    version: "2.1.0",
    credits: "Anurag Mishra",
    description: "Groq AI Bot with gender detection",
    category: "no prefix",
    usage: "bot [message]",
    cooldown: 2,
    hasPrefix: false,
    permission: "PUBLIC"
  },

  run: async function({ api, message, args }) {
    const { threadID, messageID, senderID, body } = message;
  
  if (!body || !body.toLowerCase().startsWith("bot")) return;

  const query = body.slice(3).trim();
  if (!query) {
    return api.sendMessage("Boliye, main aapki kya madad kar sakta hoon?", threadID, messageID);
  }

  // --- GROQ API KEY ---
  const GROQ_API_KEY = process.env.GROQ_API_KEY || "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"; 
  // --------------------

  try {
    let genderLabel = "User";
    try {
      const userInfo = await api.getUserInfo(senderID);
      const user = (userInfo && userInfo[senderID]) ? userInfo[senderID] : {};
      const gender = user.gender; 
      const name = user.name || "User";
      
      if (gender == 1) genderLabel = "Female (Larki)";
      else if (gender == 2) genderLabel = "Male (Larka)";
      
      const prompt = `You are a funny and cool Facebook chat bot. You are NOT an AI assistant.
      The person you are talking to is ${name} and their gender is ${genderLabel}.
      
      Owner: "Anurag Mishra".

      Rules:
      1. Don't behave like a general AI assistant.
      2. Behave like a human-like, cool, and a bit naughty/masti-mazak bot.
      3. Use very casual Hindi/Hinglish language.
      4. Keep replies VERY short and snappy.
      5. Don't mention "Anurag Mishra" unless the user specifically asks who is the owner, creator, or who made you.
      6. If the person is Female (Larki): Be a total gentleman but also flirt heavily/sweetly with emojis (😉, 😘, 😍, 🌹).
      7. If the person is Male (Larka): Do "bakchodi", roast him, use bro-talk with emojis (😂, 😎, 💩).
      8. Answer ONLY what is asked. Don't add extra information or greetings in every message.
      9. User asked: "${query}"`;

      const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model: "llama-3.3-70b-versatile",
        messages: [{ role: "user", content: prompt }]
      }, {
        headers: {
          'Authorization': `Bearer ${GROQ_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });

      const reply = response.data.choices[0].message.content;
      return api.sendMessage(reply, threadID, messageID);

    } catch (e) {
      console.error("AI Error:", e.response ? e.response.data : e.message);
      const fallback = await axios.get(`https://joshweb.click/api/gpt4?q=${encodeURIComponent(query)}`);
      return api.sendMessage(fallback.data.result || "Main abhi thoda busy hoon.", threadID, messageID);
    }
  } catch (error) {
    api.sendMessage("System error! Check API key.", threadID, messageID);
  }
  }
};
