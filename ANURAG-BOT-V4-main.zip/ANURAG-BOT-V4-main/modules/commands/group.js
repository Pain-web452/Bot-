/**
 * Group Management Command
 * Manage group settings like name, emoji, and image
 */

const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports = {
  config: {
    name: "group",
    aliases: ["grp"],
    description: "Manage group settings (name, emoji, image)",
    usages: "{prefix}group <name/emoji/image> <value>",
    credit: "𝐀𝐍𝐔𝐑𝐀𝐆 𝐌𝐈𝐒𝐇𝐑𝐀",
    category: "ADMIN",
    hasPrefix: true,
    permission: "ADMIN",
    cooldowns: 5
  },
  
  /**
   * Command execution
   * @param {Object} options - Options object
   * @param {Object} options.api - Facebook API instance
   * @param {Object} options.message - Message object
   * @param {Array<string>} options.args - Command arguments
   */
  run: async function({ api, message, args }) {
    const { threadID, messageID, senderID } = message;
    
    // Check if user is bot admin
    const isAdmin = global.config.adminIDs.includes(senderID) || global.config.ownerID === senderID;
    if (!isAdmin) {
      return api.sendMessage("❌ Only Bot Admins can use this command!", threadID, messageID);
    }
    
    // Show help if no arguments
    if (!args || args.length === 0) {
      const helpMessage = `📋 Group Management Commands:\n\n` +
        `1️⃣ ${global.config.prefix}group name <new name>\n` +
        `   • Change group name\n\n` +
        `2️⃣ ${global.config.prefix}group lockname <name/off>\n` +
        `   • Set and lock group name ('off' to unlock)\n\n` +
        `3️⃣ ${global.config.prefix}group nicklock <nickname/off>\n` +
        `   • Set and lock a specific nickname for everyone ('off' to unlock)\n\n` +
        `4️⃣ ${global.config.prefix}group autonick <format>\n` +
        `   • Set auto-nickname for new users (use {name} for their full name, 'off' to disable)\n\n` +
        `💡 Note: You must be a group admin to use these commands.`;
      
      return api.sendMessage(helpMessage, threadID, messageID);
    }
    
    const subCommand = args[0].toLowerCase();
    
    try {
      switch (subCommand) {
        case 'name':
          await handleGroupName(api, message, args.slice(1));
          break;
          
        case 'emoji':
          await handleGroupEmoji(api, message, args.slice(1));
          break;
          
        case 'image':
        case 'photo':
        case 'pic':
          await handleGroupImage(api, message);
          break;
          
        case 'adminadd':
        case 'addadmin':
          await handleAdminAdd(api, message);
          break;

        case 'lockname':
          await handleLockName(api, message, args.slice(1));
          break;

        case 'nicklock':
          await handleNickLock(api, message, args.slice(1));
          break;

        case 'autonick':
          await handleAutoNick(api, message, args.slice(1));
          break;
          
        default:
          return api.sendMessage(`❌ Invalid subcommand: ${subCommand}\n\nUse: ${global.config.prefix}group to see available options.`, threadID, messageID);
      }
    } catch (error) {
      console.error("Group command error:", error);
      return api.sendMessage("❌ An error occurred while processing the command. Please try again.", threadID, messageID);
    }
  }
};

/**
 * Handle group name change
 */
async function handleGroupName(api, message, args) {
  const { threadID, messageID } = message;
  
  if (!args || args.length === 0) {
    return api.sendMessage("❌ Please provide a new group name!\n\nExample: group name My New Group", threadID, messageID);
  }
  
  const newName = args.join(" ");
  
  if (newName.length > 100) {
    return api.sendMessage("❌ Group name is too long! Maximum 100 characters allowed.", threadID, messageID);
  }
  
  try {
    const statusMsg = await api.sendMessage("🔄 Changing group name...", threadID);
    
    const changeName = api.gcname || api.setTitle;
    if (typeof changeName !== 'function') {
       return api.sendMessage("❌ Error: Group name change function not found in bot library.", threadID, messageID);
    }

    await new Promise((resolve, reject) => {
      changeName(newName, threadID, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
    
    // Update database manually since event might not trigger for bot changes
    try {
      if (global.controllers && global.controllers.thread) {
        await global.controllers.thread.createOrUpdateThread(threadID, {
          threadName: newName
        });
        global.logger.database(`Updated thread name in database: ${threadID} (${newName})`);
      }
    } catch (dbError) {
      console.error("Error updating database:", dbError);
    }
    
    return api.editMessage(`✅ Group name changed successfully!\n📝 New name: "${newName}"`, statusMsg.messageID);
  } catch (error) {
    console.error("Error changing group name:", error);
    return api.sendMessage("❌ Failed to change group name. Make sure the bot has admin permissions.", threadID, messageID);
  }
}

/**
 * Handle group emoji change
 */
async function handleGroupEmoji(api, message, args) {
  const { threadID, messageID } = message;
  
  if (!args || args.length === 0) {
    return api.sendMessage("❌ Please provide an emoji!\n\nExample: group emoji 🎉", threadID, messageID);
  }
  
  const emoji = args[0];
  
  // Basic emoji validation
  if (emoji.length > 10) {
    return api.sendMessage("❌ Please provide a valid emoji!", threadID, messageID);
  }
  
  try {
    const statusMsg = await api.sendMessage("🔄 Changing group emoji...", threadID);
    
    await api.changeThreadEmoji(emoji, threadID);
    
    return api.editMessage(`✅ Group emoji changed successfully!\n${emoji} New emoji: ${emoji}`, statusMsg.messageID);
  } catch (error) {
    console.error("Error changing group emoji:", error);
    return api.sendMessage("❌ Failed to change group emoji. Make sure the bot has admin permissions and the emoji is valid.", threadID, messageID);
  }
}

/**
 * Handle group image change
 */
async function handleGroupImage(api, message) {
  const { threadID, messageID, messageReply } = message;
  
  // Check if message is a reply to an image
  if (!messageReply) {
    return api.sendMessage("❌ Please reply to an image with this command!\n\nExample: Reply to a photo with 'group image'", threadID, messageID);
  }
  
  // Check if replied message has attachments
  if (!messageReply.attachments || messageReply.attachments.length === 0) {
    return api.sendMessage("❌ The replied message doesn't contain any image!", threadID, messageID);
  }
  
  // Find image attachment
  const imageAttachment = messageReply.attachments.find(att => att.type === 'photo');
  
  if (!imageAttachment) {
    return api.sendMessage("❌ The replied message doesn't contain an image! Please reply to a photo.", threadID, messageID);
  }
  
  try {
    const statusMsg = await api.sendMessage("🔄 Changing group image...", threadID);
    
    // Download image
    const imageUrl = imageAttachment.url || imageAttachment.href;
    const tempDir = path.join(__dirname, '../../temporary');
    
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    
    const filename = `group_image_${Date.now()}.jpg`;
    const filepath = path.join(tempDir, filename);
    
    // Update status: downloading image
    api.editMessage("🔄 Downloading image...", statusMsg.messageID);
    
    // Download image
    const response = await axios.get(imageUrl, {
      responseType: 'stream',
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    const writer = fs.createWriteStream(filepath);
    response.data.pipe(writer);
    
    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
    
    // Update status: setting group image
    api.editMessage("🔄 Setting as group image...", statusMsg.messageID);
    
    // Change group image
    const imageStream = fs.createReadStream(filepath);
    await api.changeGroupImage(imageStream, threadID);
    
    // Clean up temp file
    setTimeout(() => {
      try {
        if (fs.existsSync(filepath)) {
          fs.unlinkSync(filepath);
        }
      } catch (e) {
        console.log("Failed to cleanup temp file:", filepath);
      }
    }, 5000);
    
    return api.editMessage("✅ Group image changed successfully! 📸", statusMsg.messageID);
    
  } catch (error) {
    console.error("Error changing group image:", error);
    return api.sendMessage("❌ Failed to change group image. Make sure the bot has admin permissions and the image is valid.", threadID, messageID);
  }
}

/**
 * Handle adding user as group admin
 */
async function handleAdminAdd(api, message) {
  const { threadID, messageID, mentions } = message;
  
  // Check if user is mentioned
  if (!mentions || Object.keys(mentions).length === 0) {
    return api.sendMessage("❌ Please mention a user to make admin!\n\nExample: group adminadd @username", threadID, messageID);
  }
  
  const mentionedUserID = Object.keys(mentions)[0];
  const mentionedUserName = mentions[mentionedUserID].replace('@', '');
  
  try {
    // Check if bot has admin permissions
    const threadInfo = await api.getThreadInfo(threadID);
    const botID = api.getCurrentUserID();
    const isBotAdmin = threadInfo.adminIDs.some(admin => admin.id === botID);
    
    if (!isBotAdmin) {
      return api.sendMessage("❌ Bot needs to be an admin to make other users admin!", threadID, messageID);
    }
    
    // Check if user is already an admin
    const isAlreadyAdmin = threadInfo.adminIDs.some(admin => admin.id === mentionedUserID);
    
    if (isAlreadyAdmin) {
      return api.sendMessage(`❌ ${mentionedUserName} is already a group admin!`, threadID, messageID);
    }
    
    // Check if mentioned user is in the group
    const isUserInGroup = threadInfo.participantIDs.includes(mentionedUserID);
    
    if (!isUserInGroup) {
      return api.sendMessage(`❌ ${mentionedUserName} is not a member of this group!`, threadID, messageID);
    }
    
    const statusMsg = await api.sendMessage(`🔄 Making ${mentionedUserName} a group admin...`, threadID);
    
    // Make user admin
    await api.changeAdminStatus(threadID, mentionedUserID, true);
    
    return api.editMessage(
      `✅ Successfully made ${mentionedUserName} a group admin!\n\n👑 New Admin: @${mentionedUserName}\n🎉 They can now manage this group.`,
      statusMsg.messageID
    );
    
  } catch (error) {
    console.error("Error making user admin:", error);
    
    let errorMessage = "❌ Failed to make user admin. ";
    
    if (error.message && error.message.includes('permission')) {
      errorMessage += "Bot doesn't have permission to make admins.";
    } else if (error.message && error.message.includes('not found')) {
      errorMessage += "User not found in this group.";
    } else {
      errorMessage += "Please try again later.";
    }
    
    return api.sendMessage(errorMessage, threadID, messageID);
  }
}

/**
 * Handle group name lock
 */
async function handleLockName(api, message, args) {
  const { threadID, messageID } = message;
  const nameToLock = args.join(" ");

  if (!nameToLock) {
    return api.sendMessage("❌ Please provide a name to lock or 'off'.\nExample: group lockname My Group Name", threadID, messageID);
  }

  if (nameToLock.toLowerCase() === 'off') {
    await global.AntiThread.findOneAndUpdate(
      { threadID },
      { groupNameLock: false },
      { upsert: true, new: true }
    );
    return api.sendMessage("✅ Group name lock has been disabled.", threadID, messageID);
  }

  await global.AntiThread.findOneAndUpdate(
    { threadID },
    { groupNameLock: true, originalGroupName: nameToLock },
    { upsert: true, new: true }
  );

  return api.sendMessage(`✅ Group name lock has been set to "${nameToLock}". I will automatically revert any unauthorized changes!`, threadID, messageID);
}

/**
 * Handle nickname lock
 */
async function handleNickLock(api, message, args) {
  const { threadID, messageID } = message;
  const nickToLock = args.join(" ");

  if (!nickToLock) {
    return api.sendMessage("❌ Please provide a nickname to lock or 'off'.\nExample: group nicklock Member", threadID, messageID);
  }

  if (nickToLock.toLowerCase() === 'off') {
    await global.AntiThread.findOneAndUpdate(
      { threadID },
      { nicknameLock: false },
      { upsert: true, new: true }
    );
    return api.sendMessage("✅ Nickname lock has been disabled.", threadID, messageID);
  }

  await global.AntiThread.findOneAndUpdate(
    { threadID },
    { nicknameLock: true, lockedNickname: nickToLock },
    { upsert: true, new: true }
  );

  // Apply to everyone currently in group
  try {
    const threadInfo = await api.getThreadInfo(threadID);
    const isBotAdmin = threadInfo.adminIDs.some(admin => admin.id === api.getCurrentUserID());
    
    if (!isBotAdmin) {
      return api.sendMessage("⚠️ Nickname lock SAVED, but bot is not an admin, so I cannot change everyone's nickname right now. Make me admin to enforce it!", threadID, messageID);
    }

    for (const userID of threadInfo.participantIDs) {
      if (userID !== api.getCurrentUserID()) {
        api.changeNickname(nickToLock, threadID, userID);
      }
    }
    return api.sendMessage(`✅ All nicknames have been set to "${nickToLock}" and LOCKED.`, threadID, messageID);
  } catch (e) {
    global.logger.error(`NickLock apply error: ${e.message}`);
    return api.sendMessage(`✅ Nickname lock enabled for "${nickToLock}".`, threadID, messageID);
  }
}

/**
 * Handle auto nickname
 */
async function handleAutoNick(api, message, args) {
  const { threadID, messageID } = message;
  const format = args.join(" ");

  if (!format) {
    return api.sendMessage("❌ Please provide a format or 'off'.\nExample: group autonick Welcome {name} ❤️", threadID, messageID);
  }

  if (format.toLowerCase() === 'off') {
    await global.AntiThread.findOneAndUpdate(
      { threadID },
      { autoNick: false },
      { upsert: true, new: true }
    );
    return api.sendMessage("✅ Auto-nickname for new users has been disabled.", threadID, messageID);
  }

  await global.AntiThread.findOneAndUpdate(
    { threadID },
    { autoNick: true, autoNickFormat: format },
    { upsert: true, new: true }
  );

  return api.sendMessage(`✅ Auto-nickname enabled with format: "${format}"`, threadID, messageID);
}
