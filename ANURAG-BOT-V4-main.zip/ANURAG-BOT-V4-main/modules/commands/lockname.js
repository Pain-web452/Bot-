module.exports = {
  config: {
    name: "lockname",
    aliases: ["locktitle"],
    description: "Set and lock group name",
    usages: "{prefix}lockname <name/off>",
    credit: "𝐀𝐍𝐔𝐑𝐀𝐆 𝐌𝐈𝐒𝐇𝐑𝐀",
    category: "ADMIN",
    hasPrefix: true,
    permission: "ADMIN",
    cooldowns: 5
  },

  run: async function({ api, message, args }) {
    const { threadID, messageID, senderID } = message;
    
    const isAdmin = global.config.adminIDs.includes(senderID) || global.config.ownerID === senderID;
    if (!isAdmin) {
      return api.sendMessage("❌ Only Bot Admins can use this command!", threadID, messageID);
    }

    const nameToLock = args.join(" ");

    if (!nameToLock) {
      return api.sendMessage("❌ Please provide a name to lock or 'off'.\nExample: #lockname My Group Name", threadID, messageID);
    }

    if (nameToLock.toLowerCase() === 'off') {
      await global.AntiThread.findOneAndUpdate(
        { threadID },
        { groupNameLock: false },
        { upsert: true, new: true }
      );
      return api.sendMessage("✅ Group name lock has been disabled.", threadID, messageID);
    }

    await global.AntiThread.findOneAndUpdate(
      { threadID },
      { groupNameLock: true, originalGroupName: nameToLock },
      { upsert: true, new: true }
    );

    // Actual lock by setting the title immediately
    // Using gcname as it's the correct function in this FCA version
    const changeName = api.gcname || api.setTitle;
    if (typeof changeName === 'function') {
      changeName(nameToLock, threadID, (err) => {
        if (err) {
          return api.sendMessage(`❌ Error setting group name: ${err.errorDescription || err.message || "Bot may not be admin"}`, threadID, messageID);
        }
      });
    } else {
      return api.sendMessage("❌ Error: Group name change function not found in bot library.", threadID, messageID);
    }

    return api.sendMessage(`✅ Group name lock has been enabled for: "${nameToLock}". I will automatically revert any unauthorized changes!`, threadID, messageID);
  }
};
