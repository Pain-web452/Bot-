const fs = require("fs");
const path = require("path");
const ytSearch = require("yt-search");
const play = require("play-dl");

module.exports.config = {
    name: "music",
    aliases: ["yt", "ytmusic"],
    version: "2.0.0",
    credit: "Bot",
    description: "Download music from YouTube",
    hasPrefix: true,
    permission: 'PUBLIC',
    category: "MEDIA",
    usages: "[url/song name]",
    cooldown: 5,
};

module.exports.run = async function ({ api, message, args }) {
    const { threadID, messageID } = message;

    if (!args.length) {
        return api.sendMessage("Please enter a song name or YouTube URL.", threadID, messageID);
    }

    const input = args.join(" ");
    let videoUrl = input;
    let videoTitle = "";
    let videoDetails = {};
    let searchingMessageInfo = null;

    try {
        const isUrl = /^(https?:\/\/)?(www\.|m\.)?(youtube\.com|youtu\.be)(\/|$)/.test(input);

        if (!isUrl) {
            searchingMessageInfo = await api.sendMessage(`Searching for: ${input}...`, threadID, messageID);
            const searchResult = await ytSearch(input);
            if (!searchResult || !searchResult.videos.length) {
                return api.sendMessage("Song not found on YouTube.", threadID, messageID);
            }
            const video = searchResult.videos[0];
            videoUrl = video.url;
            videoTitle = video.title;
            videoDetails = {
                duration: video.duration.timestamp,
                views: video.views,
                author: video.author.name,
                ago: video.ago,
            };
        } else {
            searchingMessageInfo = await api.sendMessage(`Processing URL...`, threadID, messageID);
            try {
                const videoIdMatch = input.match(/(?:youtube\.com\/(?:watch\?.*v=|shorts\/|embed\/|v\/)|youtu\.be\/)([0-9A-Za-z_-]{11})/);
                if (videoIdMatch) {
                    const videoId = videoIdMatch[1];
                    videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
                    const searchResult = await ytSearch({ videoId: videoId });
                    if (searchResult) {
                        videoTitle = searchResult.title;
                        videoDetails = {
                            duration: searchResult.duration.timestamp,
                            views: searchResult.views,
                            author: searchResult.author.name,
                            ago: searchResult.ago,
                        };
                    }
                }
            } catch (e) {
            }
        }

        const stream = await play.stream(videoUrl, { discordPlayerCompatibility: true });
        
        const tempDir = path.join(__dirname, "tempsr");
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        const safeFilename = `${Date.now()}.mp3`;
        const filePath = path.join(tempDir, safeFilename);

        const finalTitle = videoTitle || "Unknown Title";
        const formattedViews = videoDetails.views ? new Intl.NumberFormat('en-US', { notation: "compact", compactDisplay: "short" }).format(videoDetails.views) : "N/A";

        let infoMsg = `Title: ${finalTitle}\n`;
        if (videoDetails.duration) infoMsg += `Duration: ${videoDetails.duration}\n`;
        if (videoDetails.author) infoMsg += `Artist: ${videoDetails.author}\n`;
        if (videoDetails.views) infoMsg += `Views: ${formattedViews}\n`;
        if (videoDetails.ago) infoMsg += `Uploaded: ${videoDetails.ago}\n`;
        infoMsg += `Source: ${videoUrl}\n`;
        infoMsg += `Downloading...`;

        api.sendMessage(infoMsg, threadID, () => {
            if (searchingMessageInfo) {
                api.unsendMessage(searchingMessageInfo.messageID);
            }
        });

        const writer = fs.createWriteStream(filePath);
        stream.stream.pipe(writer);

        writer.on("finish", () => {
            fs.stat(filePath, (statErr, stats) => {
                if (statErr || !stats || stats.size === 0) {
                    console.error("[music] Temp file is empty or unreadable, skipping send:", filePath, statErr);
                    api.sendMessage("Download failed (empty file). Please try again.", threadID, messageID);
                    return fs.unlink(filePath, () => { });
                }

                if (stats.size > 25 * 1024 * 1024) {
                    api.sendMessage("File size exceeds 25MB limit.", threadID, messageID);
                    return fs.unlink(filePath, () => { });
                }

                api.sendMessage(
                    {
                        body: `${finalTitle}`,
                        attachment: fs.createReadStream(filePath),
                    },
                    threadID,
                    (err) => {
                        if (err) {
                            console.error("Error sending file:", err);
                            api.sendMessage("Failed to send audio file.", threadID, messageID);
                        }
                        fs.unlink(filePath, (unlinkErr) => {
                            if (unlinkErr) console.error("Error deleting temp file:", unlinkErr);
                        });
                    }
                );
            });
        });

        writer.on("error", (err) => {
            console.error("Error downloading file:", err);
            api.sendMessage("Failed to download the file.", threadID, messageID);
            fs.unlink(filePath, () => { });
        });

    } catch (error) {
        console.error("Error in music command:", error);
        api.sendMessage("An error occurred while processing your request.", threadID, messageID);
    }
};
