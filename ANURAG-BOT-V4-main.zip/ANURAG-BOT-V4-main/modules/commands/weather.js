/**
 * Weather Command
 * Shows weather information for a location
 */

module.exports = {
  config: {
    name: 'weather',
    aliases: ['mausam', 'temp'],
    description: 'Get weather information for any city',
    usage: '{prefix}weather <city name>',
    credit: 'Test User',
    hasPrefix: true,
    permission: 'PUBLIC',
    cooldown: 5,
    category: 'UTILITY'
  },
  
  run: async function({ api, message, args }) {
    const { threadID, messageID } = message;
    
    try {
      if (args.length === 0) {
        return api.sendMessage('❌ Please provide a city name.\nUsage: weather <city name>', threadID, messageID);
      }
      
      const city = args.join(' ');
      
      const axios = require('axios');
      const response = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);
      const data = response.data;
      
      if (!data || !data.current_condition || !data.current_condition[0]) {
        return api.sendMessage('❌ Could not find weather data for that location.', threadID, messageID);
      }
      
      const current = data.current_condition[0];
      const location = data.nearest_area[0];
      
      const locationName = location.areaName[0].value;
      const country = location.country[0].value;
      const tempC = current.temp_C;
      const tempF = current.temp_F;
      const feelsLikeC = current.FeelsLikeC;
      const humidity = current.humidity;
      const weatherDesc = current.weatherDesc[0].value;
      const windSpeed = current.windspeedKmph;
      const visibility = current.visibility;
      
      let weatherEmoji = '☀️';
      const desc = weatherDesc.toLowerCase();
      if (desc.includes('rain')) weatherEmoji = '🌧️';
      else if (desc.includes('cloud')) weatherEmoji = '☁️';
      else if (desc.includes('sun')) weatherEmoji = '☀️';
      else if (desc.includes('clear')) weatherEmoji = '🌤️';
      else if (desc.includes('snow')) weatherEmoji = '❄️';
      else if (desc.includes('thunder')) weatherEmoji = '⛈️';
      else if (desc.includes('fog') || desc.includes('mist')) weatherEmoji = '🌫️';
      
      let response_msg = `${weatherEmoji} 𝗪𝗘𝗔𝗧𝗛𝗘𝗥 𝗥𝗘𝗣𝗢𝗥𝗧 ${weatherEmoji}\n\n`;
      response_msg += `📍 Location: ${locationName}, ${country}\n`;
      response_msg += `━━━━━━━━━━━━━━━━━━━━\n`;
      response_msg += `🌡️ Temperature: ${tempC}°C / ${tempF}°F\n`;
      response_msg += `🤔 Feels Like: ${feelsLikeC}°C\n`;
      response_msg += `💧 Humidity: ${humidity}%\n`;
      response_msg += `💨 Wind Speed: ${windSpeed} km/h\n`;
      response_msg += `👁️ Visibility: ${visibility} km\n`;
      response_msg += `🌈 Condition: ${weatherDesc}\n`;
      response_msg += `━━━━━━━━━━━━━━━━━━━━\n`;
      response_msg += `⏰ Updated just now`;
      
      return api.sendMessage(response_msg, threadID, messageID);
      
    } catch (error) {
      global.logger.error('Error in weather command:', error.message);
      return api.sendMessage('❌ Could not fetch weather data. Please check the city name and try again.', threadID, messageID);
    }
  }
};
