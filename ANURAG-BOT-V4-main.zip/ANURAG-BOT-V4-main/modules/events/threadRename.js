/**
 * Thread Rename Event
 * Handles when a group chat's name is changed
 */

module.exports = {
  config: {
    name: 'threadRename',
    description: 'Handles thread name change events',
    version: '1.0.0',
    credit: "𝐀𝐍𝐔𝐑𝐀𝐆 𝐌𝐈𝐒𝐇𝐑𝐀"
  },
  
  run: async function({ api, message, logMessageData }) {
    const { threadID } = message;
    
    try {
      const authorID = logMessageData?.actor || message.author || message.senderID;
      
      // Get thread info from Facebook API to get the actual thread name
      let newThreadName;
      try {
        newThreadName = logMessageData?.name || 
                       message.logMessageBody?.split('named the group ')[1]?.replace('.', '') || 
                       message.body || 
                       'Unnamed Group';
      } catch (apiError) {
        global.logger.error(`Error processing thread name: ${apiError.message}`);
        newThreadName = 'Unnamed Group';
      }
      
      // Log the thread name change event
      global.logger.system(`Thread name changed in ${threadID} to "${newThreadName}" by ${authorID}`);
      
      // Check if antichange is enabled for this thread
      const antiThread = await global.AntiThread.findOne({ threadID });
      
      if (antiThread && antiThread.groupNameLock) {
        const lockedName = antiThread.originalGroupName;
        
        if (lockedName && newThreadName !== lockedName && authorID !== api.getCurrentUserID()) {
           global.logger.system(`GroupNameLock: Reverting name change in ${threadID} from "${newThreadName}" to "${lockedName}"`);
           
           // Force set the title
           const changeName = api.gcname || api.setTitle;
           if (typeof changeName === 'function') {
             changeName(lockedName, threadID, (err) => {
               if (err) global.logger.error(`Failed to revert group name: ${err.errorDescription || err.message}`);
             });
           }
           return; 
        }
      }

      // Update thread name in database
      try {
        await global.controllers.thread.createOrUpdateThread(threadID, {
          threadName: newThreadName
        });
        global.logger.database(`Updated thread name in database: ${threadID} (${newThreadName})`);
      } catch (dbError) {
        global.logger.error(`Error updating thread name in database:`, dbError.message);
      }

      // Only send notification if announceNameChange is enabled and antichange for group name is not enabled
      if (global.config.announceNameChange && (!antiThread || !antiThread.groupNameLock)) {
          let actorName = 'Someone';
          if (logMessageData.actor) {
            try {
              const userInfo = await new Promise((resolve, reject) => {
                api.getUserInfo(logMessageData.actor, (err, info) => {
                  if (err) return reject(err);
                  resolve(info);
                });
              });
              if (userInfo && userInfo[logMessageData.actor]) {
                actorName = userInfo[logMessageData.actor].name || 'Someone';
              }
            } catch (userError) {
              global.logger.error(`Error getting user info: ${userError.message}`);
            }
          }
          const notifMessage = `📝 Group name has been updated to "${newThreadName}" by ${actorName}`;
          await api.sendMessage(notifMessage, threadID);
      }
    } catch (error) {
      global.logger.error('Error in threadRename event:', error.message);
    }
  }
};