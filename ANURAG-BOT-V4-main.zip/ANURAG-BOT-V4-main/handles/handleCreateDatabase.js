/**
 * Database Creation Handler
 * Handles creation of users and threads in database
 */

const logger = global.logger || console;

module.exports = {
  createUser,
  createThread,
  createOrUpdateUser,
  createOrUpdateThread,
  ensureUserExists,
  ensureThreadExists,
  batchCreateUsers,
  batchCreateThreads,
  initializeCurrency,
  getCurrencyData,
  updateCurrency
};

async function createUser(userData) {
  try {
    const { userID, name, firstName, gender, profileUrl, vanity, isFriend } = userData;

    if (!userID) {
      logger.warn('Cannot create user without userID');
      return null;
    }

    const existingUser = await global.User.findOne({ userID });
    if (existingUser) {
      logger.debug(`User ${userID} already exists, updating...`);
      return await global.User.findOneAndUpdate(
        { userID },
        {
          name: name || existingUser.name,
          firstName: firstName || existingUser.firstName,
          gender: gender || existingUser.gender,
          profileUrl: profileUrl || existingUser.profileUrl,
          vanity: vanity || existingUser.vanity,
          isFriend: isFriend !== undefined ? isFriend : existingUser.isFriend,
          lastActive: new Date()
        },
        { new: true }
      );
    }

    const newUser = await global.User.create({
      userID,
      name: name || 'Unknown User',
      firstName: firstName || null,
      gender: gender || null,
      profileUrl: profileUrl || null,
      vanity: vanity || null,
      isFriend: isFriend || false,
      isBanned: false,
      isAdmin: false,
      isSupporter: false,
      exp: 0,
      money: 0,
      lastActive: new Date(),
      createdAt: new Date()
    });

    logger.debug(`Created new user: ${userID} (${name || 'Unknown'})`);
    return newUser;
  } catch (error) {
    logger.error('Error creating user:', error.message);
    return null;
  }
}

async function createThread(threadData) {
  try {
    const { threadID, threadName, isGroup, participantIDs, adminIDs, emoji, color, nicknames, messageCount } = threadData;

    if (!threadID) {
      logger.warn('Cannot create thread without threadID');
      return null;
    }

    const existingThread = await global.Thread.findOne({ threadID });
    if (existingThread) {
      logger.debug(`Thread ${threadID} already exists, updating...`);
      return await global.Thread.findOneAndUpdate(
        { threadID },
        {
          threadName: threadName || existingThread.threadName,
          isGroup: isGroup !== undefined ? isGroup : existingThread.isGroup,
          participantIDs: participantIDs || existingThread.participantIDs,
          adminIDs: adminIDs || existingThread.adminIDs,
          emoji: emoji || existingThread.emoji,
          color: color || existingThread.color,
          nicknames: nicknames || existingThread.nicknames,
          messageCount: messageCount || existingThread.messageCount,
          lastActive: new Date()
        },
        { new: true }
      );
    }

    const newThread = await global.Thread.create({
      threadID,
      threadName: threadName || 'Unknown Thread',
      isGroup: isGroup || false,
      participantIDs: participantIDs || [],
      adminIDs: adminIDs || [],
      emoji: emoji || null,
      color: color || null,
      nicknames: nicknames || {},
      messageCount: messageCount || 0,
      isBanned: false,
      settings: {
        prefix: global.config.prefix || '/',
        antiout: false,
        antichange: false,
        welcomeEnabled: true,
        leaveEnabled: true
      },
      lastActive: new Date(),
      createdAt: new Date()
    });

    logger.debug(`Created new thread: ${threadID} (${threadName || 'Unknown'})`);
    return newThread;
  } catch (error) {
    logger.error('Error creating thread:', error.message);
    return null;
  }
}

async function createOrUpdateUser(api, userID) {
  try {
    if (!userID) return null;

    let userInfo = null;
    try {
      const userInfoResult = await new Promise((resolve, reject) => {
        api.getUserInfo([userID], (err, info) => {
          if (err) reject(err);
          else resolve(info);
        });
      });
      userInfo = userInfoResult[userID];
    } catch (apiError) {
      logger.debug(`Could not fetch user info from API for ${userID}`);
    }

    const userData = {
      userID,
      name: userInfo?.name || 'Unknown User',
      firstName: userInfo?.firstName || null,
      gender: userInfo?.gender || null,
      profileUrl: userInfo?.profileUrl || null,
      vanity: userInfo?.vanity || null,
      isFriend: userInfo?.isFriend || false
    };

    return await createUser(userData);
  } catch (error) {
    logger.error('Error in createOrUpdateUser:', error.message);
    return null;
  }
}

async function createOrUpdateThread(api, threadID) {
  try {
    if (!threadID) return null;

    let threadInfo = null;
    try {
      threadInfo = await new Promise((resolve, reject) => {
        api.getThreadInfo(threadID, (err, info) => {
          if (err) reject(err);
          else resolve(info);
        });
      });
    } catch (apiError) {
      logger.debug(`Could not fetch thread info from API for ${threadID}`);
    }

    const threadData = {
      threadID,
      threadName: threadInfo?.threadName || threadInfo?.name || 'Unknown Thread',
      isGroup: threadInfo?.isGroup || false,
      participantIDs: threadInfo?.participantIDs || [],
      adminIDs: threadInfo?.adminIDs?.map(a => a.id) || [],
      emoji: threadInfo?.emoji || null,
      color: threadInfo?.color || null,
      nicknames: threadInfo?.nicknames || {},
      messageCount: threadInfo?.messageCount || 0
    };

    const thread = await createThread(threadData);

    if (threadInfo?.userInfo) {
      for (const user of threadInfo.userInfo) {
        await createUser({
          userID: user.id,
          name: user.name || 'Unknown User',
          firstName: user.firstName || null,
          gender: user.gender || null,
          profileUrl: user.profileUrl || null
        });
      }
    }

    return thread;
  } catch (error) {
    logger.error('Error in createOrUpdateThread:', error.message);
    return null;
  }
}

async function ensureUserExists(userID, userData = {}) {
  try {
    let user = await global.User.findOne({ userID });
    if (!user) {
      user = await createUser({ userID, ...userData });
    }
    return user;
  } catch (error) {
    logger.error('Error ensuring user exists:', error.message);
    return null;
  }
}

async function ensureThreadExists(threadID, threadData = {}) {
  try {
    let thread = await global.Thread.findOne({ threadID });
    if (!thread) {
      thread = await createThread({ threadID, ...threadData });
    }
    return thread;
  } catch (error) {
    logger.error('Error ensuring thread exists:', error.message);
    return null;
  }
}

async function batchCreateUsers(usersData) {
  try {
    const results = [];
    for (const userData of usersData) {
      const user = await createUser(userData);
      if (user) results.push(user);
    }
    logger.debug(`Batch created ${results.length} users`);
    return results;
  } catch (error) {
    logger.error('Error in batch create users:', error.message);
    return [];
  }
}

async function batchCreateThreads(threadsData) {
  try {
    const results = [];
    for (const threadData of threadsData) {
      const thread = await createThread(threadData);
      if (thread) results.push(thread);
    }
    logger.debug(`Batch created ${results.length} threads`);
    return results;
  } catch (error) {
    logger.error('Error in batch create threads:', error.message);
    return [];
  }
}

async function initializeCurrency(userID, initialBalance = 0) {
  try {
    if (!global.Currency) {
      logger.warn('Currency model not available');
      return null;
    }

    const existingCurrency = await global.Currency.findOne({ userID });
    if (existingCurrency) {
      return existingCurrency;
    }

    return await global.Currency.create({
      userID,
      balance: initialBalance,
      bank: 0,
      lastDaily: null,
      lastWork: null,
      inventory: [],
      transactions: [],
      createdAt: new Date()
    });
  } catch (error) {
    logger.error('Error initializing currency:', error.message);
    return null;
  }
}

async function getCurrencyData(userID) {
  try {
    if (!global.Currency) {
      return null;
    }

    let currency = await global.Currency.findOne({ userID });
    if (!currency) {
      currency = await initializeCurrency(userID, 0);
    }
    return currency;
  } catch (error) {
    logger.error('Error getting currency data:', error.message);
    return null;
  }
}

async function updateCurrency(userID, updateData) {
  try {
    if (!global.Currency) {
      return null;
    }

    return await global.Currency.findOneAndUpdate(
      { userID },
      updateData,
      { upsert: true, new: true }
    );
  } catch (error) {
    logger.error('Error updating currency:', error.message);
    return null;
  }
}
