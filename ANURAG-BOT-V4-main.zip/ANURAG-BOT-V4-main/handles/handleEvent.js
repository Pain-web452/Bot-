/**
 * Event Handler
 * Handles Facebook group events (join, leave, admin changes, etc.)
 */

const logger = global.logger || console;

module.exports = async function handleEvent({ api, message }) {
  try {
    if (!global.config.eventEnabled) {
      return;
    }

    const { logMessageType, logMessageData, logMessageBody, threadID, author } = message;

    if (!logMessageType) {
      return;
    }

    logger.debug(`Event received: ${logMessageType} in thread ${threadID}`);

    const thread = await global.Thread.findOne({ threadID });

    switch (logMessageType) {
      case 'log:subscribe':
        await handleSubscribe(api, message, thread);
        break;

      case 'log:unsubscribe':
        await handleUnsubscribe(api, message, thread);
        break;

      case 'log:thread-name':
        await handleThreadNameChange(api, message, thread);
        break;

      case 'log:thread-icon':
        await handleThreadIconChange(api, message, thread);
        break;

      case 'log:thread-color':
        await handleThreadColorChange(api, message, thread);
        break;

      case 'log:user-nickname':
        await handleNicknameChange(api, message, thread);
        break;

      case 'log:thread-admins':
        await handleAdminChange(api, message, thread);
        break;

      case 'log:thread-approval-mode':
        await handleApprovalModeChange(api, message, thread);
        break;

      case 'log:thread-poll':
        await handlePollEvent(api, message, thread);
        break;

      case 'log:thread-call':
        await handleCallEvent(api, message, thread);
        break;

      default:
        logger.debug(`Unhandled event type: ${logMessageType}`);
    }

    await processCustomEvents(api, message, thread);

  } catch (error) {
    logger.error('Event handler error:', error.message);
    logger.error(error.stack);
  }
};

async function handleSubscribe(api, message, thread) {
  try {
    const { logMessageData, threadID, author } = message;
    const addedParticipants = logMessageData?.addedParticipants || [];

    if (addedParticipants.length === 0) return;

    for (const participant of addedParticipants) {
      const userID = participant.userFbId;
      const userName = participant.fullName || 'New Member';

      logger.debug(`User ${userName} (${userID}) joined thread ${threadID}`);

      await global.handleCreateDatabase.ensureUserExists(userID, { name: userName });

      if (userID === global.client.botID) {
        await sendBotJoinMessage(api, threadID);
        continue;
      }

      if (thread && thread.settings && thread.settings.welcomeEnabled !== false) {
        await sendWelcomeMessage(api, threadID, userID, userName, thread);
      }
    }

    await updateThreadParticipants(api, threadID);

  } catch (error) {
    logger.error('Error handling subscribe event:', error.message);
  }
}

async function handleUnsubscribe(api, message, thread) {
  try {
    const { logMessageData, threadID, author } = message;
    const leftParticipantFbId = logMessageData?.leftParticipantFbId;

    if (!leftParticipantFbId) return;

    logger.debug(`User ${leftParticipantFbId} left thread ${threadID}`);

    if (thread && thread.settings && thread.settings.antiout) {
      try {
        await new Promise((resolve, reject) => {
          api.addUserToGroup(leftParticipantFbId, threadID, (err) => {
            if (err) reject(err);
            else resolve();
          });
        });
        
        api.sendMessage('🔄 Antiout is enabled. User has been re-added to the group.', threadID);
        logger.debug(`Re-added user ${leftParticipantFbId} due to antiout`);
        return;
      } catch (addError) {
        logger.debug(`Could not re-add user: ${addError.message}`);
      }
    }

    if (thread && thread.settings && thread.settings.leaveEnabled !== false) {
      await sendLeaveMessage(api, threadID, leftParticipantFbId, thread);
    }

    await updateThreadParticipants(api, threadID);

  } catch (error) {
    logger.error('Error handling unsubscribe event:', error.message);
  }
}

async function handleThreadNameChange(api, message, thread) {
  try {
    const { logMessageData, threadID, author } = message;
    const newName = logMessageData?.name;

    if (!newName) return;

    logger.debug(`Thread ${threadID} name changed to: ${newName}`);

    if (thread && thread.settings && thread.settings.antichange) {
      const oldName = thread.threadName;
      if (oldName && oldName !== newName) {
        try {
          await new Promise((resolve, reject) => {
            api.setTitle(oldName, threadID, (err) => {
              if (err) reject(err);
              else resolve();
            });
          });
          
          api.sendMessage('🔄 Antichange is enabled. Thread name has been restored.', threadID);
          return;
        } catch (setError) {
          logger.debug(`Could not restore thread name: ${setError.message}`);
        }
      }
    }

    await global.Thread.findOneAndUpdate(
      { threadID },
      { threadName: newName, lastActive: new Date() },
      { upsert: true }
    );

    if (global.config.announceNameChange) {
      api.sendMessage(`📝 Group name changed to: ${newName}`, threadID);
    }

  } catch (error) {
    logger.error('Error handling thread name change:', error.message);
  }
}

async function handleThreadIconChange(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;

    logger.debug(`Thread ${threadID} icon changed`);

    if (global.config.announceImageChange) {
      api.sendMessage('🖼️ Group icon has been changed.', threadID);
    }

  } catch (error) {
    logger.error('Error handling thread icon change:', error.message);
  }
}

async function handleThreadColorChange(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;
    const newColor = logMessageData?.thread_color;

    logger.debug(`Thread ${threadID} color changed to: ${newColor}`);

    await global.Thread.findOneAndUpdate(
      { threadID },
      { color: newColor, lastActive: new Date() },
      { upsert: true }
    );

  } catch (error) {
    logger.error('Error handling thread color change:', error.message);
  }
}

async function handleNicknameChange(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;
    const participantId = logMessageData?.participant_id;
    const nickname = logMessageData?.nickname;

    logger.debug(`Nickname changed in thread ${threadID}: ${participantId} -> ${nickname}`);

    if (global.config.announceNicknameChange) {
      if (nickname) {
        api.sendMessage(`✏️ Nickname changed to: ${nickname}`, threadID);
      } else {
        api.sendMessage(`✏️ Nickname removed`, threadID);
      }
    }

  } catch (error) {
    logger.error('Error handling nickname change:', error.message);
  }
}

async function handleAdminChange(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;
    const targetId = logMessageData?.TARGET_ID;
    const adminEvent = logMessageData?.ADMIN_EVENT;

    logger.debug(`Admin change in thread ${threadID}: ${targetId} - ${adminEvent}`);

    await updateThreadParticipants(api, threadID);

  } catch (error) {
    logger.error('Error handling admin change:', error.message);
  }
}

async function handleApprovalModeChange(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;
    
    logger.debug(`Approval mode changed in thread ${threadID}`);

  } catch (error) {
    logger.error('Error handling approval mode change:', error.message);
  }
}

async function handlePollEvent(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;
    
    logger.debug(`Poll event in thread ${threadID}`);

  } catch (error) {
    logger.error('Error handling poll event:', error.message);
  }
}

async function handleCallEvent(api, message, thread) {
  try {
    const { logMessageData, threadID } = message;
    
    logger.debug(`Call event in thread ${threadID}`);

  } catch (error) {
    logger.error('Error handling call event:', error.message);
  }
}

async function sendBotJoinMessage(api, threadID) {
  try {
    const prefix = global.config.prefix || '/';
    const botName = global.config.botNickname || 'FB Bot';
    
    const welcomeMsg = `👋 Hello! I'm ${botName}!

Thanks for adding me to this group!

📌 Use ${prefix}help to see available commands.
📌 My prefix is: ${prefix}

Let's have fun! 🎉`;

    api.sendMessage(welcomeMsg, threadID);
  } catch (error) {
    logger.error('Error sending bot join message:', error.message);
  }
}

async function sendWelcomeMessage(api, threadID, userID, userName, thread) {
  try {
    const threadName = thread?.threadName || 'the group';
    
    const welcomeMsg = `👋 Welcome ${userName}!

We're glad to have you in ${threadName}! 🎉

Type ${global.config.prefix || '/'}help to see what I can do!`;

    api.sendMessage(welcomeMsg, threadID);
  } catch (error) {
    logger.error('Error sending welcome message:', error.message);
  }
}

async function sendLeaveMessage(api, threadID, userID, thread) {
  try {
    let userName = 'Someone';
    
    try {
      const user = await global.User.findOne({ userID });
      if (user) {
        userName = user.name;
      }
    } catch (e) {}

    const leaveMsg = `👋 ${userName} has left the group. Goodbye!`;
    
    api.sendMessage(leaveMsg, threadID);
  } catch (error) {
    logger.error('Error sending leave message:', error.message);
  }
}

async function updateThreadParticipants(api, threadID) {
  try {
    const threadInfo = await new Promise((resolve, reject) => {
      api.getThreadInfo(threadID, (err, info) => {
        if (err) reject(err);
        else resolve(info);
      });
    });

    await global.Thread.findOneAndUpdate(
      { threadID },
      {
        participantIDs: threadInfo.participantIDs || [],
        adminIDs: threadInfo.adminIDs?.map(a => a.id) || [],
        lastActive: new Date()
      },
      { upsert: true }
    );
  } catch (error) {
    logger.debug(`Could not update thread participants: ${error.message}`);
  }
}

async function processCustomEvents(api, message, thread) {
  try {
    const events = global.client.events;
    if (!events || events.size === 0) return;

    for (const [eventName, eventHandler] of events) {
      try {
        if (eventHandler.config && eventHandler.config.eventType) {
          if (eventHandler.config.eventType !== message.logMessageType) {
            continue;
          }
        }

        if (typeof eventHandler.run === 'function') {
          await eventHandler.run({ api, message, thread });
        } else if (typeof eventHandler.execute === 'function') {
          await eventHandler.execute({ api, message, thread });
        } else if (typeof eventHandler.onEvent === 'function') {
          await eventHandler.onEvent({ api, message, thread });
        }
      } catch (eventError) {
        logger.error(`Error in custom event ${eventName}:`, eventError.message);
      }
    }
  } catch (error) {
    logger.error('Error processing custom events:', error.message);
  }
}
