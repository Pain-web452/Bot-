/**
 * Database Handler
 * Manages database initialization and operations
 */

const logger = global.logger || console;

module.exports = {
  initializeDatabase,
  syncThreads,
  syncUsers,
  getThread,
  getUser,
  updateThread,
  updateUser,
  createThread,
  createUser,
  getAllThreads,
  getAllUsers,
  deleteThread,
  deleteUser
};

async function initializeDatabase(api) {
  try {
    logger.system('Initializing database...');

    const threadCount = await global.Thread.countDocuments();
    const userCount = await global.User.countDocuments();
    
    logger.system(`Database loaded: ${threadCount} threads, ${userCount} users`);

    if (threadCount === 0) {
      logger.system('Database empty, attempting to sync threads from Facebook...');
      await syncThreadsFromFacebook(api);
    }

    logger.system('Database initialization complete');
  } catch (error) {
    logger.error('Database initialization error:', error.message);
  }
}

async function syncThreadsFromFacebook(api) {
  try {
    const threadList = await new Promise((resolve, reject) => {
      api.getThreadList(20, null, ['INBOX'], (err, threads) => {
        if (err) {
          logger.warn('Could not fetch thread list from Facebook:', err.message || err);
          resolve([]);
        } else {
          resolve(threads || []);
        }
      });
    });

    if (threadList.length === 0) {
      logger.warn('No threads fetched from Facebook. Threads will be synced as messages arrive.');
      return;
    }

    logger.system(`Fetched ${threadList.length} threads from Facebook`);

    for (const thread of threadList) {
      try {
        const threadID = thread.threadID;
        const isGroup = thread.isGroup || false;

        let threadInfo = null;
        if (isGroup) {
          try {
            threadInfo = await new Promise((resolve, reject) => {
              api.getThreadInfo(threadID, (err, info) => {
                if (err) resolve(null);
                else resolve(info);
              });
            });
          } catch (e) {
            logger.debug(`Could not get info for thread ${threadID}`);
          }
        }

        const existingThread = await global.Thread.findOne({ threadID });
        if (!existingThread) {
          await global.Thread.create({
            threadID,
            threadName: threadInfo?.threadName || thread.name || 'Unknown',
            isGroup,
            participantIDs: threadInfo?.participantIDs || [],
            adminIDs: threadInfo?.adminIDs?.map(a => a.id) || [],
            messageCount: thread.messageCount || 0,
            emoji: threadInfo?.emoji || null,
            color: threadInfo?.color || null,
            nicknames: threadInfo?.nicknames || {},
            lastActive: new Date()
          });
          logger.debug(`Created thread: ${threadID}`);
        }

        if (threadInfo && threadInfo.userInfo) {
          for (const user of threadInfo.userInfo) {
            const existingUser = await global.User.findOne({ userID: user.id });
            if (!existingUser) {
              await global.User.create({
                userID: user.id,
                name: user.name || 'Unknown User',
                gender: user.gender || null,
                profileUrl: user.profileUrl || null,
                lastActive: new Date()
              });
              logger.debug(`Created user: ${user.id}`);
            }
          }
        }
      } catch (threadError) {
        logger.error(`Error processing thread:`, threadError.message);
      }
    }

    logger.system('Thread sync from Facebook complete');
  } catch (error) {
    logger.error('Error syncing threads from Facebook:', error.message);
  }
}

async function syncThreads(api, threadIDs) {
  try {
    for (const threadID of threadIDs) {
      try {
        const threadInfo = await new Promise((resolve, reject) => {
          api.getThreadInfo(threadID, (err, info) => {
            if (err) reject(err);
            else resolve(info);
          });
        });

        await global.Thread.findOneAndUpdate(
          { threadID },
          {
            threadID,
            threadName: threadInfo.threadName || 'Unknown',
            isGroup: threadInfo.isGroup || false,
            participantIDs: threadInfo.participantIDs || [],
            adminIDs: threadInfo.adminIDs?.map(a => a.id) || [],
            emoji: threadInfo.emoji || null,
            color: threadInfo.color || null,
            nicknames: threadInfo.nicknames || {},
            lastActive: new Date()
          },
          { upsert: true, new: true }
        );

        logger.debug(`Synced thread: ${threadID}`);
      } catch (threadError) {
        logger.error(`Error syncing thread ${threadID}:`, threadError.message);
      }
    }
  } catch (error) {
    logger.error('Error in syncThreads:', error.message);
  }
}

async function syncUsers(api, userIDs) {
  try {
    const userInfos = await new Promise((resolve, reject) => {
      api.getUserInfo(userIDs, (err, info) => {
        if (err) reject(err);
        else resolve(info);
      });
    });

    for (const [userID, userInfo] of Object.entries(userInfos)) {
      await global.User.findOneAndUpdate(
        { userID },
        {
          userID,
          name: userInfo.name || 'Unknown User',
          firstName: userInfo.firstName || null,
          gender: userInfo.gender || null,
          profileUrl: userInfo.profileUrl || null,
          vanity: userInfo.vanity || null,
          isFriend: userInfo.isFriend || false,
          lastActive: new Date()
        },
        { upsert: true, new: true }
      );

      logger.debug(`Synced user: ${userID}`);
    }
  } catch (error) {
    logger.error('Error in syncUsers:', error.message);
  }
}

async function getThread(threadID) {
  try {
    return await global.Thread.findOne({ threadID });
  } catch (error) {
    logger.error('Error getting thread:', error.message);
    return null;
  }
}

async function getUser(userID) {
  try {
    return await global.User.findOne({ userID });
  } catch (error) {
    logger.error('Error getting user:', error.message);
    return null;
  }
}

async function updateThread(threadID, updateData) {
  try {
    return await global.Thread.findOneAndUpdate(
      { threadID },
      { ...updateData, lastActive: new Date() },
      { upsert: true, new: true }
    );
  } catch (error) {
    logger.error('Error updating thread:', error.message);
    return null;
  }
}

async function updateUser(userID, updateData) {
  try {
    return await global.User.findOneAndUpdate(
      { userID },
      { ...updateData, lastActive: new Date() },
      { upsert: true, new: true }
    );
  } catch (error) {
    logger.error('Error updating user:', error.message);
    return null;
  }
}

async function createThread(threadData) {
  try {
    const existingThread = await global.Thread.findOne({ threadID: threadData.threadID });
    if (existingThread) {
      return await global.Thread.findOneAndUpdate(
        { threadID: threadData.threadID },
        { ...threadData, lastActive: new Date() },
        { new: true }
      );
    }
    
    return await global.Thread.create({
      ...threadData,
      lastActive: new Date()
    });
  } catch (error) {
    logger.error('Error creating thread:', error.message);
    return null;
  }
}

async function createUser(userData) {
  try {
    const existingUser = await global.User.findOne({ userID: userData.userID });
    if (existingUser) {
      return await global.User.findOneAndUpdate(
        { userID: userData.userID },
        { ...userData, lastActive: new Date() },
        { new: true }
      );
    }
    
    return await global.User.create({
      ...userData,
      lastActive: new Date()
    });
  } catch (error) {
    logger.error('Error creating user:', error.message);
    return null;
  }
}

async function getAllThreads(filter = {}) {
  try {
    return await global.Thread.find(filter);
  } catch (error) {
    logger.error('Error getting all threads:', error.message);
    return [];
  }
}

async function getAllUsers(filter = {}) {
  try {
    return await global.User.find(filter);
  } catch (error) {
    logger.error('Error getting all users:', error.message);
    return [];
  }
}

async function deleteThread(threadID) {
  try {
    return await global.Thread.deleteOne({ threadID });
  } catch (error) {
    logger.error('Error deleting thread:', error.message);
    return null;
  }
}

async function deleteUser(userID) {
  try {
    return await global.User.deleteOne({ userID });
  } catch (error) {
    logger.error('Error deleting user:', error.message);
    return null;
  }
}
