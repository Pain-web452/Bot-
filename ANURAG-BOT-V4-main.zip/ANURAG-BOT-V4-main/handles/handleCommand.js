/**
 * Command Handler
 * Processes and executes bot commands
 */

const fs = require('fs-extra');
const path = require('path');

module.exports = async function handleCommand({ api, message, command }) {
  const { body, senderID, threadID, messageID, messageReply, attachments } = message;
  const prefix = global.config.prefix || '/';
  const logger = global.logger;

  try {
    if (!global.config.commandEnabled) {
      logger.debug('Commands are disabled globally');
      return;
    }

    const user = await global.User.findOne({ userID: senderID });
    if (user && user.isBanned) {
      logger.debug(`User ${senderID} is banned, skipping command`);
      return api.sendMessage('❌ You are banned from using this bot.', threadID, messageID);
    }

    const thread = await global.Thread.findOne({ threadID });
    if (thread && thread.isBanned) {
      logger.debug(`Thread ${threadID} is banned, skipping command`);
      return;
    }

    if (!command || !command.config) {
      logger.warn('Invalid command object received');
      return;
    }

    const commandName = command.config.name;
    const hasPrefix = body.startsWith(prefix);
    const commandBody = hasPrefix ? body.slice(prefix.length).trim() : body.trim();
    const args = commandBody.split(/\s+/).slice(1);

    // Credit Protection - Only ANURAG MISHRA credit allowed
    const validCredits = [
      'ANURAG MISHRA',
      'anurag mishra',
      'Anurag Mishra',
      '𝐀𝐍𝐔𝐑𝐀𝐆 𝐌𝐈𝐒𝐇𝐑𝐀',
      'ANURAG',
      'anurag'
    ];
    
    const commandCredit = command.config.credit || '';
    const isValidCredit = validCredits.some(valid => 
      commandCredit.toLowerCase().includes(valid.toLowerCase()) || 
      valid.toLowerCase().includes(commandCredit.toLowerCase())
    );
    
    if (!isValidCredit && commandCredit !== '') {
      logger.warn(`[CREDIT] Invalid credit "${commandCredit}" for command "${commandName}"`);
      return api.sendMessage(
        `❌ This command has invalid credit.\n\n` +
        `📛 Current Credit: ${commandCredit}\n` +
        `✅ Required Credit: ANURAG MISHRA\n\n` +
        `⚠️ To use this command, please change the credit to "ANURAG MISHRA" in the command file.`,
        threadID,
        messageID
      );
    }

    // Log command execution attempt
    logger.system(`[CMD] User: ${senderID} | Command: ${commandName}`);

    const permission = command.config.permission || 'PUBLIC';
    const hasPermission = await checkPermission(senderID, threadID, permission);
    
    if (!hasPermission) {
      return api.sendMessage('❌ You don\'t have permission to use this command.', threadID, messageID);
    }

    const cooldownTime = command.config.cooldown || 3;
    const cooldownKey = `${senderID}-${commandName}`;
    const now = Date.now();
    
    if (!global.client.cooldowns) {
      global.client.cooldowns = new Map();
    }

    const lastUsed = global.client.cooldowns.get(cooldownKey);
    if (lastUsed) {
      const remainingTime = (cooldownTime * 1000) - (now - lastUsed);
      if (remainingTime > 0) {
        const seconds = Math.ceil(remainingTime / 1000);
        return api.sendMessage(`⏳ Please wait ${seconds} second(s) before using this command again.`, threadID, messageID);
      }
    }
    
    global.client.cooldowns.set(cooldownKey, now);

    if (global.config.spamBan && global.config.spamBan.enabled) {
      const spamCheck = await checkSpam(senderID);
      if (spamCheck.isBanned) {
        return api.sendMessage(`🚫 You have been temporarily banned for spam. Ban expires in ${spamCheck.remainingTime}.`, threadID, messageID);
      }
    }

    logger.debug(`Executing command: ${commandName} by user ${senderID}`);

    let userData = user;
    if (!userData) {
      userData = await global.User.findOneAndUpdate(
        { userID: senderID },
        { 
          userID: senderID,
          name: 'Unknown User',
          lastActive: new Date()
        },
        { upsert: true, new: true }
      );
    } else {
      await global.User.updateOne(
        { userID: senderID },
        { lastActive: new Date() }
      );
    }

    let threadData = thread;
    if (!threadData) {
      threadData = await global.Thread.findOneAndUpdate(
        { threadID },
        { 
          threadID,
          threadName: 'Unknown Thread',
          lastActive: new Date()
        },
        { upsert: true, new: true }
      );
    } else {
      await global.Thread.updateOne(
        { threadID },
        { lastActive: new Date() }
      );
    }

    const runParams = {
      api,
      message,
      args,
      prefix,
      commandName,
      senderID,
      threadID,
      messageID,
      messageReply,
      attachments,
      user: userData,
      thread: threadData,
      utils: global.utils,
      logger: global.logger,
      User: global.User,
      Thread: global.Thread,
      Currency: global.Currency,
      config: global.config,
      commands: global.client.commands,
      events: global.client.events
    };

    if (typeof command.run === 'function') {
      await command.run(runParams);
    } else if (typeof command.execute === 'function') {
      await command.execute(runParams);
    } else if (typeof command.onStart === 'function') {
      await command.onStart(runParams);
    } else {
      logger.warn(`Command ${commandName} has no run/execute/onStart function`);
    }

    logger.debug(`Command ${commandName} executed successfully`);

  } catch (error) {
    logger.error('Command execution error:', error.message);
    logger.error(error.stack);
    
    try {
      api.sendMessage(`❌ An error occurred while executing the command: ${error.message}`, threadID, messageID);
    } catch (sendError) {
      logger.error('Failed to send error message:', sendError.message);
    }
  }
};

async function checkPermission(senderID, threadID, permission) {
  const ownerID = global.config.ownerID;
  const adminIDs = global.config.adminIDs || [];
  const supportIDs = global.config.supportIDs || [];

  if (senderID === ownerID) {
    return true;
  }

  switch (permission.toUpperCase()) {
    case 'PUBLIC':
    case 'USER':
    case '0':
      return true;

    case 'ADMIN':
    case 'ADMINISTRATOR':
    case '1':
      return adminIDs.includes(senderID);

    case 'OWNER':
    case 'BOT_OWNER':
    case '2':
      return senderID === ownerID;

    case 'SUPPORT':
    case 'SUPPORTER':
      return supportIDs.includes(senderID) || adminIDs.includes(senderID);

    case 'GROUP_ADMIN':
    case 'THREAD_ADMIN':
      try {
        const threadInfo = await new Promise((resolve, reject) => {
          global.api.getThreadInfo(threadID, (err, info) => {
            if (err) reject(err);
            else resolve(info);
          });
        });
        
        if (threadInfo && threadInfo.adminIDs) {
          return threadInfo.adminIDs.some(admin => admin.id === senderID);
        }
        return false;
      } catch (error) {
        global.logger.error('Error checking group admin:', error.message);
        return false;
      }

    default:
      return true;
  }
}

async function checkSpam(senderID) {
  const spamSettings = global.config.spamBan || global.config.spamBanSettings;
  if (!spamSettings || !spamSettings.enabled) {
    return { isBanned: false };
  }

  const user = await global.User.findOne({ userID: senderID });
  if (user && user.spamBan && user.spamBan.bannedUntil) {
    const now = Date.now();
    const bannedUntil = new Date(user.spamBan.bannedUntil).getTime();
    
    if (now < bannedUntil) {
      const remainingMs = bannedUntil - now;
      const hours = Math.floor(remainingMs / (1000 * 60 * 60));
      const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
      
      return {
        isBanned: true,
        remainingTime: `${hours}h ${minutes}m`
      };
    } else {
      await global.User.updateOne(
        { userID: senderID },
        { $unset: { 'spamBan.bannedUntil': 1 } }
      );
    }
  }

  return { isBanned: false };
}
